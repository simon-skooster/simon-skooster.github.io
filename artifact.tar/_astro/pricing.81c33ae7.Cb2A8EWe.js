const s="_ticks_1710s_69",t="_tick_1710s_69",_={ticks:s,tick:t},c="_slider_cgug1_16",i={switch:"_switch_cgug1_1",slider:c};export{i as a,_ as s};
